# Royal-Rebel
“The king plans to rewrite the world!” You, the Royal Rebel, make it your mission to rewrite history.
In a world with a corrupt king, a hero must step up. There is a legendary artifact that she must get to save the kingdom. However, her quest is filled with countless perils.
⚔️🛡️
